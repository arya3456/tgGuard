﻿/* 
* Name: Khodeto Beshnas
* Version: 2.0
* Developer: Hadi Akbarzadeh
* URL: FullKade.Com
* Description: Khodeto minshnasi
*/
importClass(Packages.com.fullkade.core.TB);
importClass(Packages.com.fullkade.core.db.QuerySample);
importClass(Packages.com.fullkade.core.UpdateHelper);
importClass(Packages.com.fullkade.core.methods.SendMessage);
function main(pluginName,activePlugin){
	if(UpdateHelper.isEditedMessage(update))return "1";
	var m=UpdateHelper.getMessage(update);
	if (m==null){
		if(UpdateHelper.isCallBackQuery(update)){
			m=update.callback_query.message;
			m.text=update.callback_query.data;
		}
	}
	if(m==null || !UpdateHelper.isPv(m))return "1";
	if (UpdateHelper.isText(m)){
		if (m.text=="خودتو بشناس"){
			QuerySample.Chat.setActivePlugin(m.chat.id,pluginName);
			QuerySample.Chat.setActivelevel(m.chat.id,0);
			return "3";
	    }
	}
    return "1";
}
function onActive(pluginName){
	if(!UpdateHelper.isAnyMessage(update)){return "0";}
	var sender=SendMessage(TB.getBot());
    sender.tryMode(false);
    sender.setReplyMarkup(TB.getKeyboardCancel());
    var message = UpdateHelper.getMessage(update);
    if(UpdateHelper.isEditedMessage(update)){
        return "0";
    }
    if (!UpdateHelper.isText(update)) {
        sender.send(message.chat.id,"نوع پیام صحیح نیست");
        return "0";
    }
	message.text=message.text.replace("۰","0");message.text=message.text.replace("۱","1");message.text=message.text.replace("۲","2");message.text=message.text.replace("۳","3");message.text=message.text.replace("۴","4");message.text=message.text.replace("۵","5");message.text=message.text.replace("۶","6");message.text=message.text.replace("۷","7");message.text=message.text.replace("۸","8");message.text=message.text.replace("۹","9");
    var active_level=QuerySample.Chat.getActiveLevel(message.chat.id);
	if (active_level==0) {
        if (!valid(sender,message,1300,1420)) {
            return "0";
        }

        sender.send(message.chat.id,"لطفا عدد ماه تولد خود را ارسال کنید.");
        QuerySample.Chat.setActiveValue(message.chat.id,message.text);
        QuerySample.Chat.setActivelevel(message.chat.id,1);
        
    }else if (active_level==1) {
        if (!valid(sender,message,1,12)) {
            return "0";
        }
        var value=QuerySample.Chat.getActiveValue(message.chat.id);
        sender.send(message.chat.id,"لطفا عدد روز تولد خود را ارسال کنید.");
        QuerySample.Chat.setActiveValue(message.chat.id,value + "#" +message.text);
        QuerySample.Chat.setActivelevel(message.chat.id,2);
    }else if (active_level==2) {
        if (!valid(sender,message,1,31)) {
            return "0";
        }
        
        var splites = QuerySample.Chat.getActiveValue(message.chat.id).split("#");
        var number = getResult(parseInt(splites[0]),parseInt(splites[1]),parseInt(message.text));
        
        sender.send(message.chat.id,number + " ها\n\n" + endResult(number));
		QuerySample.Chat.setActivelevel(message.chat.id,0);
		
		
		var sender2=SendMessage(TB.getBot());
		sender2.tryMode(false);
		sender2.setReplyMarkup(TB.getKeyboardCancel());
		sender2.send(message.chat.id,"می توانید سال دیگری را ارسال کنید");
    }
	
    return "0";
}
function valid(sender,message,min,max) {
    if (!isInt(message.text)) {
        sender.setReplyToMessageId(message.message_id);
        sender.send(message.chat.id,"پیام از نوع عدد نیست");
        return false;
    }
    var number = parseInt(message.text);
    if (number < min || number > max) {
        sender.setReplyToMessageId(message.message_id);
        sender.send(message.chat.id,"فقط مقدار بین " + min + " تا " + max + " پشتیبانی می شود");
        return false;
    }
    return true;
}
function isInt(value){var er = /^-?[0-9]+$/;return er.test(value);}
function getResult(y,m,d){var res = y + m + d;var str = res.toString();var numbers = str.split("");var end = res;while (numbers.length >= 2) {end = 0;for (var i = 0; i < numbers.length; i++) {try {end += parseInt(numbers[i]);}catch (eee) {}}str = end.toString();numbers = str.split("");}return end;}
function endResult(number) {
	switch (number) {
		case 1:
			return "خالق و مبتکر\n‘’یک’’ ها پایه و اساس زندگی هستند. همیشه عقاید جدید و بدیع دارند و این حالت در آنها طبیعی است. همیشه دوست دارند تمامی کارها و مسائل بر حول محوری که آنها می گویند و تعیین می کنند در گردش باشد و چون مبتکر هستند، گاهی خود خواه می شوند. با این حال ‘’یک’’ ها بشدت صادق و وفادارند و به خوبی مهارتهای سیاسی را یاد میگیرند . همیشه دوست دارند حرف اول را بزنند و غالبا رهبر و فرمانده هستند، چون عاشق این هستند که ‘’بهترین’’ باشند . در استخدام خود بودن و برای خود کار کردن بزرگترین کمک به آنهاست ولی باید یاد بگیرند عقاید دیگران ممکن است بهتر باشد و باید با رویی باز آنها را نیز بشنوند .";
		case 2:
			return "پیام آور صلح\n‘’دو’’ ها سیاستمدار به دنیا می آیند ! از نیاز دیگران خبر دارند و غالبا پیش از دیگران به آنها فکر می کنند . اصلا تنهایی را دوست ندارند . دوستی و همراهی با دیگران برایشان بسیار مهم است و می تواند آنها را به موفقیت در زندگی رهنمون سازد . اما از طرف دیگر ، چنانچه در دوستی با کسی احساس ناراحتی کنند ترجیح می دهند تنها باشند.از آنجایی که ذاتا خجالتی هستند باید در تقویت اعتماد به نفس خود تلاش کنند و با استفاده از لحظه ها و فرصت ها آنها را از دست ندهند .";
		case 3:
			return "قلب تپنده زندگی\n‘’ سه ‘’ ها ایده آلیست هستند، بسیار فعال،اجتماعی،جذاب،رمانتیک وبسیار بردبار و پر تحمل .خیلی کارها را با هم شروع می کنند اما همه آنها را پیگیری نمی کنند. دوست دارند که دیگران شاد باشند و برای این کار تمام تلاش خود رابه کار می گیرند. بسیار محبوب اجتماعی و ایده آلیست هستند اما باید یاد بگیرند که دنیا را از دید واقعگرایایه تری هم ببینند .";
		case 4:
			return "محافظه کار\n‘’چهار’’ ها بسیار حساس و سنتی هستند. آنها عاشق کارهای روزمره، روتین و پیرو نظم و انضباط هستند و تنها زمانی وارد عمل می شوند که دقیقا بدانند چه کاری باید انجام دهند. به سختی کار و تلاش می کنند. عاشق طبیعت و محیط خارج از خانه هستند . بسیار مقاوم و با پشتکار هستند. اما باید یاد بگیرند که انعطاف پذیری بیشتری داشته و با خود مهربانتر باشند .";
		case 5:
			return "ناهماهنگ با جماعت\n‘’پنج’’ ها جهانگرد هستند و کنجکاوی ذاتی، خطر پذیری و اشتیاق سیری ناپذیر آنها به جهان هستی و دیدن محیط اطراف خود،غالبا برایشان درد سر ساز می شود. آنها عاشق تنوع هستند ودوست ندارند مانند درخت در یک جا ثابت بمانند. تمام دنیا مدرسه آنهاست و در هر موقعیتی به دنبال یادگیری هستند. سوالات آنها هرگز تمام نمی شود. آنها به خوبی یاد گرفته اند که قبل از اقدام به عمل، تمامی جوانب کار را سنجیده و مطمئن شوند که پیش از نتیجه گیری ،تمامی حقایق را مد نظر قرار داده اند .";
		case 6:
			return "رمانتیک و احساساتی\n‘’ شش’’ ها ایده آلیست هستند و زمانی خوشحال می شوند که احساس مفید بودن کنند . یک رابطه خانوادگی بسیار محکم برای آنها از اهمیت ویژه ای برخوردار است. اعمالشان بر تصمیم گیری هایشان موثر است و آنها حس غریب برای مراقبت از دیگران و کمک به آنها دارند. بسیار وفادار و صادق بوده و معلمان بزرگی می شوند. عاشق هنرو موسیقی هستند . دوستانی صادق و در دوستی ثابت قدم هستند.’’شش’’ ها باید بین چیزهایی که می توانند آنها را تغییر دهند و چیزهایی که نمی توانند، تفاوت قائل شوند .";
		case 7:
			return "عاقل و خردمند\n‘’هفت’’ ها جستجو گر هستند. آنها همیشه به دنبال اطلاعات پنهان و مخفی بوده و به سختی اطلاعات به دست آمده را با ارزش حقیقی آن می پذیرند.احساسات هیچ ارتباطی با تصمیم گیری های آنها ندارد. با اینکه در مورد همه چیز در زندگی سوال می کنند اما دوست ندارند مورد پرسش واقع شوند و هیچگاه کاری را ابتدا به ساکن با سرعت شروع نمی کنند و شعارآنها این است که به آرامی می توان مسابقه را برد. آنها فیلسوفهای آینده هستند؛ طالبان علم که به هر چه می خواهند می رسند و سوال بی جوابی ندارند . مرموز هستند و در دنیای خودشان زندگی می کنند و باید یاد بگیرند در این دنیا چه چیزی قابل قبول است و چه چیزی نه!";
		case 8:
			return "آدم کله گنده\n‘’هشت ‘’ ها حلال مشکلات هستند. اساسی و حرفه ای سراغ مشکل رفته و آن را حل می کنند. قضاوتی درست دارند و بسیار مصمم هستندو طرحهاو نقشه های بزرگی دارند و دوست دارند زندگی خوبی داشته باشند. مسوولیت افراد را بر عهده می گیرند و مردم را با هدف خاص خود می بینند. با شرایط ویژه ای این امکان رابه وجود می آورند که دیگران همیشه آنها را رئیس ببینند .";
		case 9:
			return "اجرا کننده و بازیگر\n‘’نه ‘’ ها ذاتا هنرمند هستند . بسیار دلسوز دیگران و بخشنده بوده و آخرین پول جیب خود را نیز برای کمک به دیگران خرج میکنند . با جذابیت ذاتی شان اصلا در دوست یابی مشکلی ندارند و هیچ کـس برای آنها فرد غریبه ای به حساب نمی آید.در حالات مختلف شخصیت های متفاوتی از خود بروز می دهند و برای افرادی که اطرافشان هستند شناخت این افراد کمی دشوار به نظر می رسد . آنها شبیه بازیگرانی هستند که در موقعیت های مختلف رفتارهای متفاوتی نشان می دهند. افرادی خوش شانس هستند اما خیلی وقتها از آینده خود بیمناک و نسبت به آن هراسان هستند. آنها برای موفقیت باید به یک دوستی و عشق دو جانبه که می تواند مکملشان در زندگی باشد دست یابند";
	}
	return "اشتباهی رخ داد.";
}
