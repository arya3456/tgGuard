﻿/* 
* Name: Channel
* Version: 2.0
* Developer: Hadi Akbarzadeh
* URL: FullKade.Com
* Description: Send any message with keyboard to channel
*/
importClass(Packages.com.fullkade.core.TB);
importClass(Packages.com.fullkade.core.db.QuerySample);
importClass(Packages.com.fullkade.core.UpdateHelper);
importClass(Packages.com.fullkade.core.methods.SendMessage);
importClass(Packages.com.fullkade.core.methods.SendDocument);
importClass(Packages.com.fullkade.core.methods.SendVideo);
importClass(Packages.com.fullkade.core.methods.SendPhoto);
importClass(Packages.com.fullkade.core.methods.SendAudio);
importClass(Packages.com.fullkade.core.methods.SendVoice);
importClass(Packages.com.fullkade.core.methods.SendSticker);
importClass(Packages.com.fullkade.core.KeyboardHelper);
importClass(Packages.com.fullkade.core.InlineKeyboardMarkupConvertor);
importClass(Packages.com.fullkade.core.types.ReplyKeyboardMarkup);
importClass(Packages.com.fullkade.core.types.KeyboardButton);
importClass(Packages.com.fullkade.core.types.InlineKeyboardMarkup);
importClass(Packages.com.fullkade.core.types.InlineKeyboardButton);
importClass(Packages.com.fullkade.core.JsonHelper);
importClass(Packages.com.fullkade.core.StringHelper);
importClass(org.json.JSONObject);

function main(pluginName,activePlugin) {
	if(UpdateHelper.isEditedMessage(update))return "1";
	var m=UpdateHelper.getMessage(update);
	if (m==null){
		if(UpdateHelper.isCallBackQuery(update)){
			m=update.callback_query.message;
			m.text=update.callback_query.data;
		}
	}
	if(m==null || !UpdateHelper.isPv(m))return "1";
    if (UpdateHelper.isText(m)) {
        if (m.text=="ارسال مطلب به کانال") {
            QuerySample.Chat.setActivePlugin(m.chat.id,pluginName);
            QuerySample.Chat.setActivelevel(m.chat.id,0);
            return "3";
        }
    }
    return "1";
}

var MODE_TEXT = 1;
var MODE_PHOTO = 2;
var MODE_VIDEO = 3;
var MODE_AUDIO = 4;
var MODE_STICKER = 5;
var MODE_VOICE = 6;
var MODE_DOCUMENT = 7;

var sender;
var message;

function onActive(pluginName) {
	if(!UpdateHelper.isAnyMessage(update)){return "0";}
    sender=SendMessage(TB.getBot());
    sender.tryMode(false);
    message = UpdateHelper.getMessage(update);
	if (UpdateHelper.isEditedMessage(update)){
			return "0";
	}
	switch (QuerySample.Chat.getActiveLevel(message.chat.id)) {
		// On get message mode and value
		case 0: { 
			var jsonObject = JSONObject();
			if (UpdateHelper.isText(update)) {
				jsonObject.put("MODE", MODE_TEXT);
				jsonObject.put("VALUE", message.text);
			}
			else if (UpdateHelper.isPhoto(update)) {
				jsonObject.put("MODE", MODE_PHOTO);
				jsonObject.put("VALUE", UpdateHelper.getPhotoFileId(update));
			}
			else if (UpdateHelper.isVideo(update)) {
				jsonObject.put("MODE", MODE_VIDEO);
				jsonObject.put("VALUE", message.video.file_id);
			}
			else if (UpdateHelper.isVoice(update)) {
				jsonObject.put("MODE", MODE_VOICE);
				jsonObject.put("VALUE", message.voice.file_id);
			}
			else if (UpdateHelper.isSticker(update)) {
				jsonObject.put("MODE", MODE_STICKER);
				jsonObject.put("VALUE", message.sticker.file_id);
			}
			else if (UpdateHelper.isAudio(update)) {
				jsonObject.put("MODE", MODE_AUDIO);
				jsonObject.put("VALUE", message.audio.file_id);
			} else if (UpdateHelper.isDocument(update)) {
				jsonObject.put("MODE", MODE_DOCUMENT);
				jsonObject.put("VALUE", message.document.file_id);
			} else {
				sender.setReplyMarkup(TB.getKeyboardCancel());
				sender.send(message.chat.id, "نوع پیام پشتیبانی نمی شود.");
				return "0";
			}
			saveJson(jsonObject);
			setLevel(1); // Have Keyboard?
			
			sender.setReplyMarkup(getKeyboardYesNo());
			sender.send(message.chat.id, "آیا می خواهید کیبورد داشته باشید؟");
			return "0";
		}
		// Have Keyboard?
		case 1: { 
			if (!UpdateHelper.isText(update)) {
				sender.setReplyMarkup(getKeyboardYesNo());
				sender.send(message.chat.id, "لطفا جواب صحیح ارسال نمایید.");
				return "0";
			}
		
			var jsonObject = loadJson();
			
			if (message.text == "آره") {
				jsonObject.put("HAVE_KEYBOARD", true);
				jsonObject.put("KEYBOARD_LEVEL", 0);
				sender.setReplyMarkup(TB.getKeyboardCancel());
				sender.send(message.chat.id, "نام اولین دکمه کیبورد خود را ارسال کنید");
				saveJson(jsonObject);
				setLevel(2); // On Keyboard
			} else if (message.text == "نه") {
				jsonObject.put("HAVE_KEYBOARD", false);
				levelCaption(jsonObject);
			} else {
				sender.setReplyMarkup(getKeyboardYesNo());
				sender.send(message.chat.id, "لطفا جواب صحیح ارسال نمایید.");
			}
			return "0";
		}
		// On Keyboard
		case 2: { 
			if (!UpdateHelper.isText(update)) {
				sender.setReplyMarkup(getKeyboardYesNo());
				sender.send(message.chat.id, "لطفا پیام متنی ارسال کنید.");
				return "0";
			}
			
			var jsonObject = loadJson();
			
			var keyboard_level = keyboard_level = jsonObject.getInt("KEYBOARD_LEVEL");
			
			switch (keyboard_level) {
				case 0: { // First time
					onAddingButton(jsonObject, false, -1);
					return "0";
				}
				case 1: { // Request link
					if (message.text.length() > 85) {
						sender.setReplyMarkup(TB.getKeyboardCancel());
						sender.send(message.chat.id, "طول لینک حداکثر می تواند تا 85 کاراکتر باشد.");
						return "0";
					}
					var lastKeyboardJson = addButtonLink(jsonObject.getString("KEYBOARD_INLINE"), message.text, jsonObject.getInt("KEYBOARD_ROW"), jsonObject.getInt("KEYBOARD_COL"));
					jsonObject.put("KEYBOARD_INLINE", lastKeyboardJson);
					jsonObject.put("KEYBOARD_ROW", -1);
					jsonObject.put("KEYBOARD_COL", -1);
					jsonObject.put("KEYBOARD_LEVEL", 2); // Request link
					saveJson(jsonObject);
					sender.setReplyMarkup(getKeyboardOnAdded());
					sender.send(message.chat.id, "دکمه با موفقیت اضافه شد");
					return "0";
				}
				case 2: { // Tools
					if (message.text == "پیش نمایش") {
						demo();
						return "0";
					}
					
					if (message.text == "کیبورد نمیخوام") {
						jsonObject.put("HAVE_KEYBOARD", false);
						levelCaption(jsonObject);
						return "0";
					}
					
					if (message.text == "سطر جدید") {
						jsonObject.put("KEYBOARD_LEVEL", 3); // New row
						saveJson(jsonObject);
						sender.setReplyMarkup(TB.getKeyboardCancel());
						sender.send(message.chat.id, "لطفا عنوان دکمه را وارد کنید");
						return "0";
					}
					
					if (message.text == "انتخاب سطر") {
						jsonObject.put("KEYBOARD_LEVEL", 4); // On Select Rows
						var inlineKeyboardMarkup = JsonHelper.getInlineKeyboardMarkup(jsonObject.getString("KEYBOARD_INLINE"));
						var size = inlineKeyboardMarkup.inline_keyboard.size();
						jsonObject.put("KEYBOARD_SIZE", size);
						saveJson(jsonObject);
						sender.setReplyMarkup(getRowsKeyboard(size));
						sender.send(message.chat.id, "شماره سطر هایی که ساخته اید برایتان ارسال شد. یکی را انتخاب کنید.");
						return "0";
					}
					
					if (message.text == "از اول") {
						jsonObject.put("KEYBOARD_LEVEL", 0);
						saveJson(jsonObject);
						sender.setReplyMarkup(TB.getKeyboardCancel());
						sender.send(message.chat.id, "نام اولین دکمه کیبورد خود را ارسال کنید");
						return "0";
					}
					
					if (message.text == "مرحله بعدی") {
						levelCaption(jsonObject);
						return "0";
					}
					
					sender.setReplyMarkup(getKeyboardOnAdded());
					sender.send(message.chat.id, "لطفا دستور صحیح ارسال کنید.");
					return "0";
				}
				case 3: { // New Row on old
					onAddingButton(jsonObject, true, -1);
					return "0";
				}
				case 4: { // New Row on old
					var inlineKeyboardMarkup = JsonHelper.getInlineKeyboardMarkup(jsonObject.getString("KEYBOARD_INLINE"));
					var size = jsonObject.getInt("KEYBOARD_SIZE");
					if (!isInt(message.text)) {
						sender.setReplyMarkup(getRowsKeyboard(size));
						sender.send(message.chat.id, "لطفا پیام عددی ارسال کنید.");
						return "0";
					}
					
					var current_row = parseInt(message.text);
					if (current_row > size || current_row < 0) {
						sender.setReplyMarkup(getRowsKeyboard(size));
						sender.send(message.chat.id, "این سطری که گفتی وجود نداره");
						return "0";
					}
					
					
					jsonObject.put("KEYBOARD_TOROW", current_row - 1);
					jsonObject.put("KEYBOARD_LEVEL", 5);
					saveJson(jsonObject);
					
					sender.setReplyMarkup(TB.getKeyboardCancel());
					sender.send(message.chat.id, "نام دکمه را وارد کنید.");
					
					return "0";
				}
				case 5: { // Add to current row
					onAddingButton(jsonObject, true, jsonObject.getInt("KEYBOARD_TOROW"));
					return "0";
				}
			}
			
			return "0";
		}
		// Have Caption
		case 3: {
			if (!UpdateHelper.isText(update)) {
				sender.setReplyMarkup(getKeyboardYesNo());
				sender.send(message.chat.id, "لطفا جواب صحیح ارسال نمایید.");
				return "0";
			}
			var jsonObject = loadJson();
			if (message.text == "آره") {
				jsonObject.put("HAVE_CAPTION", true);
				sender.setReplyMarkup(TB.getKeyboardCancel());
				sender.send(message.chat.id, "لطفا زیر نویس را وارد کنید.");
				saveJson(jsonObject);
				setLevel(4); // On Caption
			} else  if (message.text == "نه") {
				jsonObject.put("HAVE_CAPTION", false);
				sender.setReplyMarkup(TB.getKeyboardCancel());
				sender.send(message.chat.id, "لطفا یوزر نیم کانال خود را  خود را به همراه @ وارد کنید.");
				saveJson(jsonObject);
				setLevel(5); // On Username
			} else {
				sender.setReplyMarkup(getKeyboardYesNo());
				sender.send(message.chat.id, "لطفا جواب صحیح ارسال نمایید.");
			}
			return "0";
		}
		// On Caption
		case 4: { 
			if (!UpdateHelper.isText(update)) {
				sender.setReplyMarkup(TB.getKeyboardCancel());
				sender.send(message.chat.id, "لطفا زیر نویس صجیج ارسال نمایید.");
				return "0";
			}
			
			if (message.text.length() > 200) {
				sender.setReplyMarkup(TB.getKeyboardCancel());
				sender.send(message.chat.id, "طول زیر نویس باید کم تر از 200 حرف باشد.");
				return "0";
			}
			
			var jsonObject = loadJson();
			jsonObject.put("CAPTION", message.text);
			sender.setReplyMarkup(TB.getKeyboardCancel());
			sender.send(message.chat.id, "لطفا یوزر نیم کانال خود را  خود را به همراه @ وارد کنید.");
			setLevel(5);
			saveJson(jsonObject);
			
			return "0";
		}
		// On Username
		case 5: {
			if (!UpdateHelper.isText(update)) {
				sender.setReplyMarkup(TB.getKeyboardCancel());
				sender.send(message.chat.id, "لطفا یوزر نیم صحیح ارسال نمایید.");
				return "0";
			}
			
			sendToChannel(message.text);
			
			return "0";
		}
	}
	
    return "0";
}

function demo() {
	var listner = new function() {
		this.okTrue = function (message) {
		};
		this.okFalse = function (error_code,description) {
			sender.setReplyMarkup(getKeyboardOnAdded());
			sender.send(message.chat.id, "ناتوانی در پیش نمایش" + "\n" + "ممکن است کیبورد ساختار اشتباهی داشته باشد." + "\n\nتوضیحات:\n" + description);
		};
		this.onFail = function (statucCode) {
			return false;
		};
	};
	sendEnd(listner, message.chat.id);
}

function sendToChannel(channelUsername) {
	var chat_id = message.chat.id;
	
	var listner = new function() {
		this.okTrue = function (message) {
			setLevel(0);
			sender.setReplyMarkup(TB.getKeyboardCancel());
			sender.send(chat_id, "با موفقیت ارسال شد. می توانید از ابتدا شروع کنید. لطفا پیام جدید خود را ارسال کنید.");
		};
		this.okFalse = function (error_code,description) {
			setLevel(5);
			sender.setReplyMarkup(TB.getKeyboardCancel());
			sender.send(chat_id, "ارسال نشد. ممکن است یوزرنیم اشتباه بوده باشد! و یا شاید من ادمین کانال نباشم. لطفا دوباره یوزرنیم خود را ارسال نمایید تا دوباره ارسال کنم.");
		};
		this.onFail = function (statucCode) {
			return false;
		};
	};
	
	sendEnd(listner,channelUsername);
}

function sendEnd(listner,to) {
	var jsonObject = loadJson();
	var channelSender;
	switch (jsonObject.getInt("MODE")) {
		case MODE_TEXT: {
			channelSender = SendMessage(TB.getBot());
			channelSender.setParseMode("HTML"); // Markdown
		} break;
		case MODE_PHOTO: {
			channelSender = SendPhoto(TB.getBot());
		} break;
		case MODE_VIDEO: {
			channelSender = SendVideo(TB.getBot());
		} break;
		case MODE_AUDIO: {
			channelSender = SendAudio(TB.getBot());
		} break;
		case MODE_STICKER: {
			channelSender = SendSticker(TB.getBot());
		} break;
		case MODE_VOICE: {
			channelSender = SendVoice(TB.getBot());
		} break;
		case MODE_DOCUMENT: {
			channelSender = SendDocument(TB.getBot());
		} break;
	}
	if (listner != null) {
		channelSender.setOnMessageListner(listner);
	}
	else {
		channelSender.tryMode(false);
	}
	if (jsonObject.has("HAVE_CAPTION")) {
		if (jsonObject.getBoolean("HAVE_CAPTION")) {
			channelSender.setCaption(jsonObject.getString("CAPTION"));
		}
	}
	
	if (jsonObject.has("HAVE_KEYBOARD")) {
		if (jsonObject.getBoolean("HAVE_KEYBOARD")) {
			channelSender.setKeyboardJSON(jsonObject.getString("KEYBOARD_INLINE"));
		}
	}
	
	channelSender.send(to, jsonObject.getString("VALUE"));
}

function keyboardAddToCurrentRow(current_row) {
	sender.setReplyMarkup(TB.getKeyboardCancel());
}

function onAddingButton(jsonObject, haveOld, toRow) {
	if (message.text.length() > 50) {
		sender.send(message.chat.id, "طول دکمه حداکثر می تواند تا 50 کاراکتر باشد.");
		return;
	}
	
	var inlineKeyboardMarkup;
	var lastJson = null;
	var size = 0;
	if (haveOld) {
		lastJson = jsonObject.getString("KEYBOARD_INLINE");
	    inlineKeyboardMarkup = JsonHelper.getInlineKeyboardMarkup(lastJson);
		size = inlineKeyboardMarkup.inline_keyboard.size();
	}
	lastJson = addButtonText(lastJson, message.text, toRow);
	TB.log(lastJson);
	jsonObject.put("KEYBOARD_INLINE", lastJson);
	if (toRow == -1) {
		jsonObject.put("KEYBOARD_ROW", size);
		jsonObject.put("KEYBOARD_COL", 0);
	} else {
		jsonObject.put("KEYBOARD_ROW", toRow);
		jsonObject.put("KEYBOARD_COL", inlineKeyboardMarkup.inline_keyboard.get(toRow).size());
	}
	jsonObject.put("KEYBOARD_LEVEL", 1); // Request link
	saveJson(jsonObject);
	sender.setReplyMarkup(TB.getKeyboardCancel());
	sender.send(message.chat.id, "لطفا لینک دکمه را ارسال کنید.");
}

// Need
function addButtonText(json,text,rowNumber) {
	var inlineKeyboardMarkup;
	TB.log("rowNumber = " + rowNumber);
	if (json == null) {
		inlineKeyboardMarkup = InlineKeyboardMarkup();
	} else {
		inlineKeyboardMarkup = JsonHelper.getInlineKeyboardMarkup(json);
	}
	
	var button = InlineKeyboardButton();
    button.text = text;
    
	var row;
	if (rowNumber == -1) { //Creat new row
		row = KeyboardHelper.creatInlineRow();
		row.add(button);
	    inlineKeyboardMarkup.inline_keyboard.add(row);
	} else {
		inlineKeyboardMarkup.inline_keyboard.get(rowNumber).add(button);
	}
	return JsonHelper.creatJson(inlineKeyboardMarkup);
}

function addButtonLink(json,link,rowNumber,colNumber) {
	var inlineKeyboardMarkup = JsonHelper.getInlineKeyboardMarkup(json);
	inlineKeyboardMarkup.inline_keyboard.get(rowNumber).get(colNumber).url = link;
	return JsonHelper.creatJson(inlineKeyboardMarkup);
}
//
function levelCaption(jsonObject) {
	if (haveCaption(jsonObject.getInt("MODE"))) {
		saveJson(jsonObject);
		setLevel(3); // Have Caption?
		sender.setReplyMarkup(getKeyboardYesNo());
		sender.send(message.chat.id, "آیا می خواهید زیر نویس داشته باشید؟");
	} else {
		jsonObject.put("HAVE_CAPTION", false);
		// Vaqti na mikhad keyboard dashte bashe na Caption -- > Request channel username
		saveJson(jsonObject);
		setLevel(5); // On Username
		sender.setReplyMarkup(TB.getKeyboardCancel());
		sender.send(message.chat.id, "لطفا یوزر نیم کانال خود را  خود را به همراه @ وارد کنید.");
	}
}
function getRowsKeyboard(size) {
	var replyKeyboardMarkup = ReplyKeyboardMarkup();
	
	for (var i=0; i< size; i++) {
		var row = KeyboardHelper.creatRow();
	    var button = KeyboardButton();
	    button.text = (i + 1) + "";
	    row.add(button);
	    replyKeyboardMarkup.keyboard.add(row);
	}
	
	replyKeyboardMarkup.keyboard.add(getCancelRow());
    
	return replyKeyboardMarkup;
}
function getKeyboardOnAdded() {
	var replyKeyboardMarkup = ReplyKeyboardMarkup();

	var rows1 = KeyboardHelper.creatRow();
    var button1_1 = KeyboardButton();
    button1_1.text = "انتخاب سطر";
    rows1.add(button1_1);
    var button1_2 =  KeyboardButton();
    button1_2.text = "سطر جدید";
    rows1.add(button1_2);
    replyKeyboardMarkup.keyboard.add(rows1);
    
    var rows2 = KeyboardHelper.creatRow();
    var button2_1 =  KeyboardButton();
    button2_1.text = "کیبورد نمیخوام";
    rows2.add(button2_1);
    var button2_2 =  KeyboardButton();
    button2_2.text = "پیش نمایش";
    rows2.add(button2_2);
    replyKeyboardMarkup.keyboard.add(rows2);
    
    var rows3 = KeyboardHelper.creatRow();
    var button3_1 =  KeyboardButton();
    button3_1.text = "از اول";
    rows3.add(button3_1);
    var button3_2 =  KeyboardButton();
    button3_2.text = "مرحله بعدی";
    rows3.add(button3_2);
    replyKeyboardMarkup.keyboard.add(rows3);
    
    replyKeyboardMarkup.keyboard.add(getCancelRow());
    
    return replyKeyboardMarkup;
}

//
function getKeyboardYesNo() {
	var replyKeyboardMarkup = ReplyKeyboardMarkup();
    var rows1 = KeyboardHelper.creatRow();
    var button1 = KeyboardButton();
    button1.text = "نه";
    rows1.add(button1);
    var button2 =  KeyboardButton();
    button2.text = "آره";
    rows1.add(button2);
    replyKeyboardMarkup.keyboard.add(rows1);
    replyKeyboardMarkup.keyboard.add(getCancelRow());
    return replyKeyboardMarkup;
}
function getCancelRow() {
	var row = KeyboardHelper.creatRow();
    var button = KeyboardButton();
    button.text = TB.getCancelCMD();
    row.add(button);
    return row;
    
}
function haveCaption(mode) {
	if (mode == MODE_VIDEO || mode == MODE_PHOTO || mode == MODE_DOCUMENT) {
		return true;
	}
	return false;
}
function isInt(value){var er = /^-?[0-9]+$/;return er.test(value);}
function setLevel(level){QuerySample.Chat.setActivelevel(message.chat.id,level);}
function loadJson(){return JSONObject(QuerySample.Chat.getActiveValue(message.chat.id));}
function saveJson(jsonObject){QuerySample.Chat.setActiveValue(message.chat.id,jsonObject.toString());}