﻿/* 
* Name: Administrators
* Version: 2.0
* Developer: Hadi Akbarzadeh
* URL: FullKade.Com
* Description: Administrators commonds on gp
*/
importClass(Packages.com.fullkade.core.TB);
importClass(Packages.com.fullkade.core.UpdateHelper);
importClass(Packages.com.fullkade.core.methods.SendMessage);
importClass(Packages.com.fullkade.core.methods.GetChatAdministrators);
importClass(Packages.com.fullkade.core.methods.KickChatMember);
importClass(Packages.com.fullkade.core.methods.LeaveChat);
var message;
var remoters=["1","2"];
var adminstrators=true;
var sender;
function main(pluginName,activePlugin){
	if(UpdateHelper.isEditedMessage(update)){return "1";}
	message=UpdateHelper.getMessage(update);
	if(message==null){return "1";}
	if(!UpdateHelper.isGroup(message)){return "1";}
	if (UpdateHelper.isText(message)) {
		sender=SendMessage(TB.getBot());
		sender.tryMode(false);
		sender.setReplyToMessageId(message.message_id);
		if (message.text=="لف بده ربات") {doLeft();return "0";}
		if (UpdateHelper.isReply(message)) {
			if (message.text=="کیک شو"){kickSho();return "0";}
			if (message.text=="آیدی بده"){getId();return "0";}
			return "1";
		}
	}
    return "1";
}
function kickSho(){
	var onIsAdmin=function(){
		if(UpdateHelper.isReplyTo(message, TB.getMyId())){
			sender.send(message.chat.id, "خودمو که نمی تونم کیک کنم خخخخخ");
		}else if(!UpdateHelper.isReplyTo(update, message.from.id)){
			onKick();
		}else{sender.send(message.chat.id, "هه خودتو که نمی تونم کیک کنم");}
	};
	var onIsNotAdmin=function(){
		sender.send(message.chat.id, "تو ریموت رباتو نداری");
	};
	run(onIsAdmin,onIsNotAdmin);
}
function onKick(){
	var kicker=KickChatMember(TB.getBot());
	var listner=new function(){
		this.okTrue=function(){
			sender.send(message.chat.id, "شوت شد");
		};
		this.okFalse=function(error_code,description){
			sender.send(message.chat.id, "نمی تونم کیک کنم\n\nDescription: " + description);
		};
		this.onFail=function(statucCode){return false;};
	};
	kicker.setOnSuccessListner(listner);
	kicker.kick(message.chat.id, message.reply_to_message.from.id);
}
function doLeft(){
	var onIsAdmin=function(){
		var leaver=LeaveChat(TB.getBot());
		leaver.leave(message.chat.id);
	};
	var onIsNotAdmin=function(){sender.send(message.chat.id, "من به حرف تو گوش نمی دم");};
	run(onIsAdmin,onIsNotAdmin);
}
function getId(){
	var onIsAdmin=function(){
		sender.send(message.chat.id, "ID = "+message.reply_to_message.from.id);
	};
	var onIsNotAdmin=function(){sender.send(message.chat.id, "من به حرف تو گوش نمی دم");};
	run(onIsAdmin,onIsNotAdmin);
}
function run(onIsAdmin,onIsNotAdmin){
	if(adminstrators){
		var adminGeter=GetChatAdministrators(TB.getBot());
		var listner=new function(){
			this.okTrue=function (chatMembers){
				for (var i = 0; i < chatMembers.size(); i++){
					if (chatMembers.get(i).user.id==message.from.id){
						onIsAdmin();
						return;
					}
				}
				onIsNotAdmin();
			};
			this.okFalse=function (error_code,description){
				sender.send(message.chat.id,"نمی تونم لیست ادمین هارو بررسی کنم شاید خودم ادمین نیستم"+"\n\n"+description);
			};
			this.onFail=function (statucCode){return false;};
		};
		adminGeter.setOnChatMemberListner(listner);
		adminGeter.start(message.chat.id);
	}else{for (i = 0; i < remoters.length; i++){if (remoters[i]==message.from.id){onIsAdmin();return;}}onIsNotAdmin();}
}