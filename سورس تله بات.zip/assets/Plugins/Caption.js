/* 
* Name: Caption
* Version: 2.0
* Developer: Hadi Akbarzadeh
* URL: FullKade.Com
* Description: Adding caption to files
*/
importClass(Packages.com.fullkade.core.TB);
importClass(Packages.com.fullkade.core.db.QuerySample);
importClass(Packages.com.fullkade.core.UpdateHelper);
importClass(Packages.com.fullkade.core.methods.SendMessage);
importClass(Packages.com.fullkade.core.methods.SendDocument);
importClass(Packages.com.fullkade.core.methods.SendVideo);
importClass(Packages.com.fullkade.core.methods.SendPhoto);
function main(pluginName,activePlugin){
	if(UpdateHelper.isEditedMessage(update))return "1";
	var m=UpdateHelper.getMessage(update);
	if (m==null){
		if(UpdateHelper.isCallBackQuery(update)){
			m=update.callback_query.message;
			m.text=update.callback_query.data;
		}
	}
	if(m==null || !UpdateHelper.isPv(m))return "1";
	if (UpdateHelper.isText(m)){
		if (m.text=="زیر نویس"){
			QuerySample.Chat.setActivePlugin(m.chat.id,pluginName);
			QuerySample.Chat.setActivelevel(m.chat.id,0);
			return "3";
	    }
	}
    return "1";
}
function onActive(pluginName){
	if(!UpdateHelper.isAnyMessage(update)){return "0";}
	var sender=SendMessage(TB.getBot());
	sender.tryMode(false);
	sender.setReplyMarkup(TB.getKeyboardCancel());
	var message = UpdateHelper.getMessage(update);
	if(UpdateHelper.isEditedMessage(update)){
    	sender.setReplyToMessageId(message.message_id);
    	sender.send(message.chat.id,"ادیت کنی  جواب نمی دم");
    	return "0";
	}
    var active_level=QuerySample.Chat.getActiveLevel(message.chat.id);
    if (active_level==0) {
		// send file
		var file_id = null;
        if (UpdateHelper.isDocument(update)) {
            file_id = "#do#" + message.document.file_id;
        } else if (UpdateHelper.isVideo(update)) {
            file_id = "#vi#" + message.video.file_id;
        } else if (UpdateHelper.isPhoto(update)) {
            file_id = "#ph#" + UpdateHelper.getPhotoFileId(update);
        }
        if (file_id!=null) {
        	sender.send(message.chat.id,"لطفا زیر نویس را وارد کنید");
        	QuerySample.Chat.setActiveValue(message.chat.id,file_id);
        	QuerySample.Chat.setActivelevel(message.chat.id,1);
        } else {
        	sender.send(message.chat.id,"لطفا فقط فایل یا ویدیو یا عکس ارسال نمایید");
        }
    } else if (active_level==1) {
    	if (message.text!=null) {
    		var value=QuerySample.Chat.getActiveValue(message.chat.id);
    		var find;
    		var resSender;
    		if (value.startsWith("#do#")) {
    			find="#do#";
    			resSender=SendDocument(TB.getBot());
    		}else if (value.startsWith("#vi#")) {
    			find="#vi#";
    			resSender=SendVideo(TB.getBot());
    		}else if (value.startsWith("#ph#")) {
    			find="#ph#";
    			resSender=SendPhoto(TB.getBot());
    		}
    		value=value.replace(find,"");
    		var listner = new function() {
    			this.okTrue = function (message) {
    				var sender=SendMessage(TB.getBot());
    				sender.tryMode(false);
    				sender.setReplyMarkup(TB.getKeyboardCancel());
    				sender.send(message.chat.id, "می توانید فایل دیگری را برای زیر نویس دار کردن ارسال نمایید");
    				QuerySample.Chat.setActivelevel(message.chat.id,0);
    			};
    			this.okFalse = function (error_code,description) {
    				var sender=SendMessage(TB.getBot());
    				sender.tryMode(false);
    				sender.setReplyMarkup(TB.getKeyboardCancel());
    				sender.send(message.chat.id,"متاسفانه خطای " +
    						description +
    						" رخ داد." +
    						"\n\nتعداد کاراکتر نیز بایستی کم تر از 200 تا باشد.");
    			};
    		    this.onFail = function (statucCode) {
    		        return false;
    		    };
    		 };
    		 resSender.setOnMessageListner(listner);
    		 resSender.setCaption(message.text);
    		 resSender.send(message.chat.id,value);
    	} else {
			sender.send(message.chat.id,"لطفا فقط متن ارسال نمایید");
    	}
    }
    return "0";
}
