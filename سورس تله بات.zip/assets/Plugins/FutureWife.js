/* 
* Name: Future Wife
* Version: 2.0
* Develper: Hadi Akbarzadeh
* URL: FullKade.Com
* Description: Fun
*/
importClass(Packages.com.fullkade.core.TB);
importClass(Packages.com.fullkade.core.db.QuerySample);
importClass(Packages.com.fullkade.core.UpdateHelper);
importClass(Packages.com.fullkade.core.KeyboardHelper);
importClass(Packages.com.fullkade.core.methods.SendMessage);
importClass(Packages.com.fullkade.core.types.ReplyKeyboardMarkup);
importClass(Packages.com.fullkade.core.types.KeyboardButton);
function main(pluginName,activePlugin){
	if(UpdateHelper.isEditedMessage(update))return "1";
	var m=UpdateHelper.getMessage(update);
	if (m==null){
		if(UpdateHelper.isCallBackQuery(update)){
			m=update.callback_query.message;
			m.text=update.callback_query.data;
		}
	}
	if(m==null || !UpdateHelper.isPv(m))return "1";
	if (UpdateHelper.isText(m)){
		if (m.text=="پیشگویی همسر آینده") {
			QuerySample.Chat.setActivePlugin(m.chat.id,pluginName);
	        return "3";
	    }
	}
    return "1";
}
function onActive(pluginName){
	if(!UpdateHelper.isAnyMessage(update)){return "0";}
	var sender=SendMessage(TB.getBot());
	sender.tryMode(false);
	sender.setReplyMarkup(getKeyboard());
	var message = UpdateHelper.getMessage(update);
	var result="";
    if(UpdateHelper.isEditedMessage(update)){
    	sender.setReplyToMessageId(message.message_id);
    	result = "ادیت کنی  جواب نمی دم";
	}else if(update.message.text=="دخترم"){
    	var boys=["هادی","مهدی","علی","رضا","محمد","حسین","حسن","ولی","ناصر","حمید", "پوریا","رحمن","بهزاد","سعید","صمد","سینا","نیما","غضنفر","رجب"];
    	result=boys[Math.floor(Math.random()*boys.length)];
    }else if(update.message.text=="پسرم"){
    	var girls=["آیدا","الناز","سوگند","ملیکا","نرگس","نسترن","رقیه","زینب","مریم","مریم","باران","فاطمه","حنانه","هما"];
    	result=girls[Math.floor(Math.random() * girls.length)];
    }else{
    	result="لطفا گزینه صحیح را انتخاب نمایید";
    }
    sender.send(message.chat.id,result);
    return "0";
}
function getKeyboard() {
	var replyKeyboardMarkup = ReplyKeyboardMarkup();
    var rows1 = KeyboardHelper.creatRow();
    var button1 = KeyboardButton();
    button1.text = "دخترم";
    rows1.add(button1);
    var button2 =  KeyboardButton();
    button2.text = "پسرم";
    rows1.add(button2);
    replyKeyboardMarkup.keyboard.add(rows1);
    var rows2 = KeyboardHelper.creatRow();
    var button3 = KeyboardButton();
    button3.text = TB.getCancelCMD();
    rows2.add(button3);
    replyKeyboardMarkup.keyboard.add(rows2);
    replyKeyboardMarkup.one_time_keyboard=true;
    return replyKeyboardMarkup;
}