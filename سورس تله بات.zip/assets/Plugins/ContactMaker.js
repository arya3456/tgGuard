﻿/* 
* Name: ContactMaker
* Version: 2.0
* Developer: Hadi Akbarzadeh
* URL: FullKade.Com
* Description: Creat contact and share it
*/
importClass(Packages.com.fullkade.core.TB);
importClass(Packages.com.fullkade.core.db.QuerySample);
importClass(Packages.com.fullkade.core.UpdateHelper);
importClass(Packages.com.fullkade.core.methods.SendMessage);
importClass(Packages.com.fullkade.core.methods.SendContact);
importClass(Packages.com.fullkade.core.KeyboardHelper);
importClass(Packages.com.fullkade.core.types.ReplyKeyboardMarkup);
importClass(Packages.com.fullkade.core.types.KeyboardButton);
importClass(org.json.JSONObject);
function main(pluginName,activePlugin) {
	if(UpdateHelper.isEditedMessage(update))return "1";
	var m=UpdateHelper.getMessage(update);
	if (m==null){
		if(UpdateHelper.isCallBackQuery(update)){
			m=update.callback_query.message;
			m.text=update.callback_query.data;
		}
	}
	if(m==null || !UpdateHelper.isPv(m))return "1";
	if (UpdateHelper.isText(m)){
        if (m.text=="ساخت مخاطب") {
            QuerySample.Chat.setActivePlugin(m.chat.id,pluginName);
            QuerySample.Chat.setActivelevel(m.chat.id,0);
            return "3";
        }
    }
	return "1";
}
var sender;
var message;
function onActive(pluginName){
	if(!UpdateHelper.isAnyMessage(update)){return "0";}
	sender=SendMessage(TB.getBot());
    sender.tryMode(false);
	sender.setReplyMarkup(TB.getKeyboardCancel());
    message = UpdateHelper.getMessage(update);
	if (UpdateHelper.isEditedMessage(update)){
			return "0";
	}
	if (!UpdateHelper.isText(update)) {
		sender.send(message.chat.id, "لطفا پیام متنی ارسال کنید.");
		return "0";
	}
	switch (QuerySample.Chat.getActiveLevel(message.chat.id)) {
		case 0: {
			if (message.text.length() > 50) {
				sender.send(message.chat.id, "طول شماره نمی تواند از 50 بیشتر باشد.");
				return "0";
			}
			var jsonObject = JSONObject();
			jsonObject.put("phone_number", message.text);
			saveJson(jsonObject);
			setLevel(1);
			sender.send(message.chat.id, "لطفا نام مخاطب را وارد کنید.");
			return "0";
		}
		case 1: {
			if (message.text.length() > 50) {
				sender.send(message.chat.id, "طول نام نمی تواند بیشتر از 50 حرف باشد.");
				return "0";
			}
			var jsonObject = loadJson();
			jsonObject.put("first_name", message.text);
			saveJson(jsonObject);
			setLevel(2);
			sender.setReplyMarkup(getKeyboardYesNo());
			sender.send(message.chat.id, "آیا می خواهید نام خانوادگی داشته باشد؟");
			return "0";
		}
		case 2: {
			var jsonObject = loadJson();
			if (message.text == "آره") {
				saveJson(jsonObject);
				setLevel(3);
				sender.setReplyMarkup(TB.getKeyboardCancel());
				sender.send(message.chat.id, "نام خانوادگی  مورد نظر خود را ارسال کنید.");
			} else if (message.text == "نه") {
				sendContact(jsonObject);
			} else {
				sender.setReplyMarkup(getKeyboardYesNo());
				sender.send(message.chat.id, "لطفا جواب صحیح ارسال نمایید.");
			}
			return "0";
		}
		case 3: {
			if (message.text.length() > 50) {
				sender.send(message.chat.id, "طول نام نمی تواند بیشتر از 50 حرف باشد.");
				return "0";
			}
			var jsonObject = loadJson();
			jsonObject.put("last_name", message.text);
			sendContact(jsonObject);
			return "0";
		}
	}
	return "0";
}
function sendContact(jsonObject) {
	var cSender=SendContact(TB.getBot());
	var listner = new function() {
		this.okTrue = function (message) {
			setLevel(0);
			sender.send(message.chat.id, "می توانید شماره دیگری را ارسال کنید.");
		};
		this.okFalse = function (error_code,description) {
			setLevel(0);
			sender.send(message.chat.id, "نمی تونم مخاطبیو که میخوای بسازم، شاید درست و حسابی اطلاعاتو وارد نکردی... یه شماره دیگه بفرست تا دوباره بسازم." + "\n\nتوضیحات اضافی: " + description);
		};
		this.onFail = function (statucCode) {
			return false;
		};
	};
	cSender.setOnMessageListner(listner);
	if (jsonObject.has("last_name"))
		cSender.setLastName(jsonObject.getString("last_name"));
	cSender.send(UpdateHelper.getMessage(update).chat.id, jsonObject.getString("phone_number"), jsonObject.getString("first_name"));
}
function getKeyboardYesNo() {
	var replyKeyboardMarkup = ReplyKeyboardMarkup();
    var rows1 = KeyboardHelper.creatRow();
    var button1 = KeyboardButton();
    button1.text = "نه";
    rows1.add(button1);
    var button2 =  KeyboardButton();
    button2.text = "آره";
    rows1.add(button2);
    replyKeyboardMarkup.keyboard.add(rows1);
    replyKeyboardMarkup.keyboard.add(getCancelRow());
    return replyKeyboardMarkup;
}
function getCancelRow() {
	var row = KeyboardHelper.creatRow();
    var button = KeyboardButton();
    button.text = TB.getCancelCMD();
    row.add(button);
    return row;
    
}
function setLevel(level){QuerySample.Chat.setActivelevel(message.chat.id,level);}
function loadJson(){return JSONObject(QuerySample.Chat.getActiveValue(message.chat.id));}
function saveJson(jsonObject){QuerySample.Chat.setActiveValue(message.chat.id,jsonObject.toString());}