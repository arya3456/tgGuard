﻿/*
 * Tele Bot Script Engine
 * Powered by FullKade.Com
 * Core.js
 */
importClass(Packages.com.fullkade.core.TB);

function main() {
	TB.core(update);
	return "0";
}